import java.util.Scanner;

public class baitap5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Đầu vào (Input)
		Scanner scan = new Scanner(System.in);
		int so = 0;
		int so_hang_dv = so % 10;
		int so_hang_chuc = so/ 10;
		
		// Xử lý (Process)
		System.out.println("Nhập vào 1 số có 2 chữ số (VD:12,49,98)");
		System.out.println("Bước 1: Nhập số hàng đơn vị");
		so_hang_dv = scan.nextInt();
		System.out.println("Bước 2:Nhập số hàng chục");
		so_hang_chuc = scan.nextInt();
	
		// Đầu ra (Output)
		System.out.println("Tổng 2 ký số vừa nhập là: "+(so_hang_dv+so_hang_chuc));
		
	}

}
