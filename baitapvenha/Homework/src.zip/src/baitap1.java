import java.util.Scanner;

public class baitap1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Đầu vào (Input)
			Scanner scan = new Scanner (System.in);
			int days;
			int salary = 100000;
		
		
		
		// Xử lý (Process)
			System.out.println("HỆ THỐNG TÍNH LƯƠNG TỰ ĐỘNG");
			System.out.println("Mời nhập số ngày làm việc");
			days = scan.nextInt();
			
			
		// Đầu ra (Output)
			System.out.println("Tiền lương tháng này của bạn là: "+ (days * salary));
		
		
	}

}
