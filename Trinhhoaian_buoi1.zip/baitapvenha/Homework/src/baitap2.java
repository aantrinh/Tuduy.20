import java.util.Scanner;

public class baitap2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Đầu vào (Input)
		Scanner scan = new Scanner (System.in);
		int so_1;
		int so_2;
		int so_3;
		int so_4;
		int so_5;
		
		// Xử lý (Process)
		System.out.println("Mời bạn nhập số thứ nhất");
		so_1 = scan.nextInt();
		System.out.println("Mời bạn nhập số thứ hai");
		so_2 = scan.nextInt();
		System.out.println("Mời bạn nhập số thứ ba");
		so_3 = scan.nextInt();
		System.out.println("Mời bạn nhập số thứ tư");
		so_4 = scan.nextInt();
		System.out.println("Mời bạn nhập số thứ năm");
		so_5 = scan.nextInt();
		
		// Đầu ra (Output)
		System.out.println("Giá trị trung bình là "+(so_1+so_2+so_3+so_4+so_5)/5 );
		
		
		
			
	}

}
